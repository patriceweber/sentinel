
""" Sentinel module:
    Contains all the plumbing (functions and classes) necessary to make the workflow
    script run smooothly """

import sentinel.utils
import sentinel.downloader
import sentinel.workflow

